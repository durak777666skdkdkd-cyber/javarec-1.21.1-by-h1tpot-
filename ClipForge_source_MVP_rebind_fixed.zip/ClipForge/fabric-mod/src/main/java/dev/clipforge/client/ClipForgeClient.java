package dev.clipforge.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.net.HttpURLConnection;
import java.net.URL;

public class ClipForgeClient implements ClientModInitializer {
    private static KeyBinding openPanel;

    @Override public void onInitializeClient() {
        openPanel = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.clipforge.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyBinding.Category.MISC));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openPanel.wasPressed()) client.setScreen(new ClipForgeScreen());
        });
    }

    static void send(String command) {
        Thread thread = new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL("http://127.0.0.1:18765/" + command).openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(700);
                connection.setReadTimeout(1200);
                connection.getResponseCode();
            } catch (Exception ignored) {
            } finally {
                if (connection != null) connection.disconnect();
            }
        }, "ClipForge-IPC");
        thread.setDaemon(true);
        thread.start();
    }

    private static class ClipForgeScreen extends Screen {
        private boolean waitingForKey = false;
        private ButtonWidget rebindButton;

        protected ClipForgeScreen() { super(Text.literal("ClipForge")); }
        @Override protected void init() {
            int cx = width / 2, y = height / 2 - 82;
            addDrawableChild(ButtonWidget.builder(Text.literal("Начать запись"), b -> send("start"))
                    .dimensions(cx - 100, y, 200, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Пауза / продолжить"), b -> send("pause"))
                    .dimensions(cx - 100, y + 25, 200, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Остановить и сохранить"), b -> send("stop"))
                    .dimensions(cx - 100, y + 50, 200, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Клип 30 секунд"), b -> send("clip30"))
                    .dimensions(cx - 100, y + 75, 200, 20).build());
            rebindButton = addDrawableChild(ButtonWidget.builder(rebindLabel(), b -> {
                        waitingForKey = true;
                        b.setMessage(Text.literal("Нажми новую клавишу… (Esc — отмена)"));
                    }).dimensions(cx - 100, y + 100, 200, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Закрыть"), b -> close())
                    .dimensions(cx - 100, y + 128, 200, 20).build());
        }

        private Text rebindLabel() {
            return Text.literal("Клавиша меню: ").append(openPanel.getBoundKeyLocalizedText());
        }

        @Override public boolean keyPressed(KeyInput input) {
            if (waitingForKey) {
                int keyCode = input.key();
                if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                    waitingForKey = false;
                    if (rebindButton != null) rebindButton.setMessage(rebindLabel());
                    return true;
                }
                openPanel.setBoundKey(InputUtil.fromKeyCode(input));
                KeyBinding.updateKeysByCode();
                client.options.write();
                waitingForKey = false;
                if (rebindButton != null) rebindButton.setMessage(rebindLabel());
                return true;
            }
            return super.keyPressed(input);
        }

        @Override public boolean shouldPause() { return false; }
    }
}
