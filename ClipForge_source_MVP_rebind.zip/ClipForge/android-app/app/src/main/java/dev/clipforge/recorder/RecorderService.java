package dev.clipforge.recorder;

import android.app.*;
import android.app.Service;
import android.content.pm.ServiceInfo;
import android.content.*;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class RecorderService extends Service {
    private MediaProjection projection; private VirtualDisplay display; private MediaRecorder recorder;
    private ServerSocket server; private Thread serverThread; private int width=1920,height=1080,fps=60; private boolean paused=false, recording=false;
    @Override public void onCreate(){ super.onCreate(); createChannel(); }
    @Override public int onStartCommand(Intent i,int flags,int id){
        if(i==null) return START_NOT_STICKY;
        width=i.getIntExtra("width",1920); height=i.getIntExtra("height",1080); fps=i.getIntExtra("fps",60);
        Notification notification = new Notification.Builder(this,"clipforge").setContentTitle("ClipForge активен").setContentText("Запись экрана доступна из Minecraft").setSmallIcon(android.R.drawable.presence_video_online).build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(7, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION); else startForeground(7, notification);
        Intent token=i.getParcelableExtra("data"); int result=i.getIntExtra("resultCode",Activity.RESULT_CANCELED);
        if(token!=null){ projection=((MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE)).getMediaProjection(result,token); startServer(); }
        return START_NOT_STICKY;
    }
    private void createChannel(){ if(Build.VERSION.SDK_INT>=26){ NotificationChannel c=new NotificationChannel("clipforge","ClipForge recorder",NotificationManager.IMPORTANCE_LOW); ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c); } }
    private void startServer(){ serverThread=new Thread(()->{ try(ServerSocket s=new ServerSocket()){ server=s; s.bind(new InetSocketAddress("127.0.0.1",18765)); while(!Thread.currentThread().isInterrupted()){ try(Socket client=s.accept()){ BufferedReader r=new BufferedReader(new InputStreamReader(client.getInputStream())); String line=r.readLine(); String path=line==null?"":line.split(" ")[1]; while((line=r.readLine())!=null&&!line.isEmpty()){} handle(path); client.getOutputStream().write("HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nOK".getBytes()); } } }catch(Exception ignored){} }); serverThread.start(); }
    private synchronized void handle(String path){ if(path.startsWith("/start")) startRecording(); else if(path.startsWith("/stop")) stopRecording(); else if(path.startsWith("/pause")){ if(recording){ try{ if(!paused){ recorder.pause(); paused=true; } else { recorder.resume(); paused=false; } }catch(Exception ignored){} } } else if(path.startsWith("/clip30")){ startRecording(); new Handler(Looper.getMainLooper()).postDelayed(this::stopRecording,30000); } }
    private void startRecording(){ if(recording||projection==null)return; try{
        File dir=new File(getExternalFilesDir(null),"Clips"); if(!dir.exists())dir.mkdirs(); String stamp=new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date()); File out=new File(dir,"clip_"+stamp+".mp4");
        recorder=new MediaRecorder(); recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE); recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4); recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
        recorder.setVideoSize(width,height); recorder.setVideoFrameRate(fps); recorder.setVideoEncodingBitRate(Math.max(8_000_000,width*height*fps/8)); recorder.setOutputFile(out.getAbsolutePath()); recorder.prepare();
        display=projection.createVirtualDisplay("ClipForge",width,height,getResources().getDisplayMetrics().densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,recorder.getSurface(),null,null); recorder.start(); recording=true; paused=false;
    }catch(Exception e){ stopRecording(); } }
    private synchronized void stopRecording(){ if(!recording)return; try{ if(paused)recorder.resume(); recorder.stop(); }catch(Exception ignored){} try{recorder.reset();recorder.release();}catch(Exception ignored){} try{display.release();}catch(Exception ignored){} recorder=null;display=null;recording=false;paused=false; }
    @Override public void onDestroy(){ stopRecording(); try{if(server!=null)server.close();}catch(Exception ignored){} if(projection!=null)projection.stop(); super.onDestroy(); }
    @Override public android.os.IBinder onBind(Intent intent){return null;}
}
