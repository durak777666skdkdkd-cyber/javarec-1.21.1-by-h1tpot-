package dev.clipforge.recorder;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.widget.*;
import android.view.ViewGroup;

public class MainActivity extends Activity {
    private static final int CAPTURE_REQUEST = 7401;
    private Spinner resolution, fps;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,36,28,28);
        root.setBackgroundColor(0xFF101018);
        TextView title = new TextView(this); title.setText("ClipForge • Screen Recorder"); title.setTextColor(-1); title.setTextSize(23); root.addView(title);
        TextView info = new TextView(this); info.setText("Выбери профиль. Android покажет системный запрос на запись экрана."); info.setTextColor(0xFFCCCCDD); root.addView(info);
        resolution = new Spinner(this); resolution.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new String[]{"1080p", "1440p (2K)", "2160p (4K)"})); root.addView(resolution);
        fps = new Spinner(this); fps.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new String[]{"60 FPS", "120 FPS"})); root.addView(fps);
        Button grant = new Button(this); grant.setText("Разрешить запись экрана"); grant.setOnClickListener(v -> {
            Intent capture = ((MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE)).createScreenCaptureIntent();
            startActivityForResult(capture, CAPTURE_REQUEST);
        }); root.addView(grant);
        TextView note = new TextView(this); note.setText("Важно: доступные разрешение и FPS определяются экраном и аппаратным кодировщиком. 4K/120 FPS не гарантируется."); note.setTextColor(0xFFFFCC88); root.addView(note);
        setContentView(root);
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request,result,data);
        if (request == CAPTURE_REQUEST && result == RESULT_OK && data != null) {
            Intent service = new Intent(this, RecorderService.class);
            service.putExtra("resultCode", result); service.putExtra("data", data);
            service.putExtra("width", new int[]{1920,2560,3840}[resolution.getSelectedItemPosition()]);
            service.putExtra("height", new int[]{1080,1440,2160}[resolution.getSelectedItemPosition()]);
            service.putExtra("fps", fps.getSelectedItemPosition()==0?60:120);
            startForegroundService(service);
            Toast.makeText(this,"Разрешение получено. Сервис записи запущен.",Toast.LENGTH_LONG).show();
        }
    }
}
